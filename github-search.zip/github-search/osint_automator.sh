#!/bin/bash

# Crear una carpeta para almacenar los resultados
TARGET="hostinger.com"
OUTPUT_DIR="osint_results_$TARGET"
mkdir -p $OUTPUT_DIR

echo "Iniciando recolección OSINT para $TARGET..."
echo "Resultados serán guardados en $OUTPUT_DIR"

# 1. Recolección de subdominios adicionales con crt.sh
echo "Recolectando subdominios adicionales desde crt.sh..."
curl -s "https://crt.sh/?q=$TARGET" > $OUTPUT_DIR/subdominios_crtsh.txt

# 2. Búsqueda de correos electrónicos con The Harvester
echo "Buscando correos electrónicos con The Harvester..."
theHarvester -d $TARGET -b all -f $OUTPUT_DIR/emails_harvester.txt

# 3. Búsqueda de documentos y archivos públicos (Google Hacking)
echo "Buscando documentos públicos con Google Hacking..."
echo "site:$TARGET filetype:pdf OR filetype:xlsx OR filetype:doc" > $OUTPUT_DIR/google_dorks.txt

# 4. Extracción de metadatos de documentos con FOCA
echo "Analizando metadatos con FOCA (si tienes archivos)..."
# FOCA es una herramienta gráfica, pero aquí incluimos la instrucción manualmente.

# 5. Búsqueda de información en GitHub (GitHub-Search by Gwen001)
echo "Buscando información sensible en GitHub..."
python3 github-secrets.py -d $TARGET > $OUTPUT_DIR/github_secrets.txt

# 6. Buscar variaciones tipográficas del dominio con DNSTwist
echo "Buscando dominios similares con DNSTwist..."
dnstwist -r $TARGET > $OUTPUT_DIR/dnstwist_results.txt

# 7. Análisis de redes sociales con Maltego (se puede integrar manualmente si es necesario)
echo "Si tienes acceso a Maltego, puedes ejecutar manualmente las transformaciones."

# 8. Realizar búsqueda inversa de imágenes (Instrucción manual)
echo "Puedes realizar búsquedas inversas manuales en Google Images o Yandex."

# 9. Búsqueda de documentos públicos en Google Drive
echo "Buscando documentos públicos en Google Drive..."
echo "site:drive.google.com inurl:$TARGET" >> $OUTPUT_DIR/google_drive_search.txt

# Finalización
echo "Recolección de OSINT completa. Los resultados están en la carpeta $OUTPUT_DIR."
